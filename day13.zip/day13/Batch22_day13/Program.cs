﻿using System;

namespace Batch22_day13
{
    interface One
    {
        void method1();
        void message();
    }
    interface Two
    {
        void method2();
        void message();
    }
    class Implement:One,Two
    {
        public void method1()
        {
            Console.WriteLine("METHOD 1");
        }
        public void method2()
        {
            Console.WriteLine("METHOD 2");
        }
        public void message()
        {
            Console.WriteLine("Message");
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Implement ob1 = new Implement();
            ob1.method1();
            ob1.method2();
            ob1.message();
        }
    }
}
