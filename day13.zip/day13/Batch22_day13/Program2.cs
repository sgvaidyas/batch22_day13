﻿using System;

namespace Batch22_day13
{
    class Program2
    {
        static void Main(string[] args)
        {
            GalleryProj ob = new GalleryProj();
            ob.display();
        }
    }
}
