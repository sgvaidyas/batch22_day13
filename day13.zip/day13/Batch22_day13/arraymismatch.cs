﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Batch22_day13
{
    class arraymismatch
    {
        static void Main(string[] args)
        {
            string[] a = new string[3] { "apple","mango","orange" };
            object[] b = (object[]) a;

            try
            {
                b[0] = (object)88;
                foreach (object x in b)
                {
                    Console.WriteLine(x);
                }
            }
            catch(ArrayTypeMismatchException ob)
            {
                Console.WriteLine(ob.Message);
            }
        }
    }
}
