﻿using System;

namespace Batch22_day13
{
    class Exception1
    {
        static void Main(string[] args)
        {
            int res, a, b;

            Console.WriteLine("Enter a and b");
            a = int.Parse(Console.ReadLine());
            b = int.Parse(Console.ReadLine());
            try
            {
                res = a / b;
                Console.WriteLine("Res = " + res);
            }
            catch(DivideByZeroException ob)
            {
                Console.WriteLine("Divide by zero error"+ ob.Message);
            }
            catch(Exception ob)
            {
                Console.WriteLine("Generic = "+ob.Message);
            }
            

            Console.WriteLine("hhhhhhhhhhhh = " );
            Console.WriteLine("hhhhhhhhhhhhhhhh = " );
            Console.WriteLine("bbbbbbbbb = " );
            Console.WriteLine("Res = " );


        }
    }
}
