﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Batch22_day13
{
    class Invalidcast
    {
        static void Main(string[] args)
        {
            string s;
            int val;
            bool val2=true;
            try
            {
                Console.WriteLine("Enter a val =");
                s = Console.ReadLine();
                //FormatException in case if you supply string like ab778
                val = Convert.ToInt32(s);
                //throwing invalid cast using Iconvertable
                IConvertible c = val2;
                //Directly use this before the above line ArgumentNullException
                Char ch = c.ToChar(null);               
                val2 = Convert.ToBoolean(s);
                Console.WriteLine("int val of {0}  is {1}",s,val);
            }
            catch(FormatException ob)
            {
                Console.WriteLine(ob.Message);
            }
            catch(ArgumentNullException ob)
            {
                Console.WriteLine("Arg null exc " + ob.Message);
            }
            catch(InvalidCastException ob)
            {
                Console.WriteLine("invalid cast = "+ob.Message);
            }


         }
    }
}
