﻿using System;

namespace MyNamespace
{    
    class Namespace1
    {
        public int len, bred, rad,  peri;
        public float area;
        string ch;
        public enum Shapes{
            Circle=100,
            Square =38,
            Rectangle=62 
        };
        public Namespace1()
        {
            Console.WriteLine("Enter choice Circle,Square,rectangle");
            ch = Console.ReadLine();

            if (ch == "Circle")
            {
                Console.WriteLine("Enter radius");
                rad = int.Parse(Console.ReadLine());
            }
                
            else if (ch == "Square")
            {
                Console.WriteLine("Enter len");
                len = int.Parse(Console.ReadLine());
            }
                
            else if (ch == "Rectangle")
            {
                Console.WriteLine("Enter len & breadth");
                len = int.Parse(Console.ReadLine());
                bred = int.Parse(Console.ReadLine());
            }
            else
                Console.WriteLine("Invalid choice");
        }

        public void areafun()
        {
            if (ch == "Circle")
                area = 3.142f * rad * rad;
            else if (ch == "Square")
                area = len * len;
            else if (ch == "Rectangle")
                area = len * bred;
            else
                area = 0;
        }
        public void checkvalidity()
        {
            foreach(Shapes shape in Enum.GetValues(typeof(Shapes)))
            {
                if(shape.ToString()==ch)
                {
                    string valid = (area >= (int)shape) ? "valid" : "invalid";
                    Console.WriteLine("{0} Shape with area = {1} is {2}",ch,area,valid);
                }
            }
        }
        
    }
}
