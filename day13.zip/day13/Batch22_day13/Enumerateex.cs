﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Batch22_day13
{
    class Enumerateex
    {
        public enum Products
        {
            Earphone=499,
            Tripod = 999,
            keypad =334,
            sdcard = 788
        };
        static void Main(string[] args)
        {
            //Console.WriteLine(Enumerateex.Days.Thu + "  =  " + (int)Enumerateex.Days.Thu);
            string s = "Earphone=499\n Tripod = 999\n keypad = 334\n sdcard = 788";
            Console.WriteLine(s + "\n Enter the choice");
            string ch= Console.ReadLine();
            Console.WriteLine("Enter qty ");
            int qty = int.Parse(Console.ReadLine());
            int price=0;
            switch(ch)
            {
                case "Earphone":price = qty *(int) Enumerateex.Products.Earphone;
                    break;
                case "Tripod":
                    price = qty * (int)Enumerateex.Products.Tripod;
                    break;
                case "keypad":
                    price = qty * (int)Enumerateex.Products.keypad;
                    break;
                case "sdcard":
                    price = qty * (int)Enumerateex.Products.sdcard;
                    break;
                default: Console.WriteLine("invalid");break;
            }
            Console.WriteLine("PRICE = " + price);
        }

    }
}


