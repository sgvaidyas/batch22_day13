﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Batch22_day13
{
    class NullExcept1
    {
        static void Main(string[] args)
        {
            string s=null;
            try
            {
                Console.WriteLine(s.Length);
            }
            catch(NullReferenceException ob)
            {
                Console.WriteLine("NULL REF = " + ob.Message);
            }
            
        }
    }
}
