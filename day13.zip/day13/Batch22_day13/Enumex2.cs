﻿using System;

namespace Batch22_day13
{
    class Enumex2
    {
        public enum Products
        {
            Earphone = 499,
            Tripod = 999,
            keypad = 334,
            sdcard = 788
        };
        static void Main(string[] args)
        {
            foreach(int i in Enum.GetValues(typeof(Products)))
            {
                Console.WriteLine(i);
            }
            foreach (string name in Enum.GetNames(typeof(Products)))
            {
                Console.WriteLine(name);
            }
            Console.WriteLine();
            string s = "Earphone=499\n Tripod = 999\n keypad = 334\n sdcard = 788";
            Console.WriteLine(s + "\n Enter the choice");
            string ch = Console.ReadLine();

            Console.WriteLine("Enter qty ");
            int qty = int.Parse(Console.ReadLine());
            Console.WriteLine("__________________");
            int price = 0;
            foreach (Products prod in Enum.GetValues(typeof(Products)))
            {
                if (ch == prod.ToString())
                {
                    Console.WriteLine(prod + "  " + (int)prod);
                    price = qty * (int)prod;
                }
            }
            Console.WriteLine("PRICE = " + price);
        }
    }
}
