﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Batch22_day13
{
    class Indexoutofrange1
    {
        static void Main(string[] args)
        {
            int[] a = new int[5] { 11, 22, 33, 44, 55 };
            int ind;

            try
            {
                Console.WriteLine("Enter index");
                ind = int.Parse(Console.ReadLine());
                Console.WriteLine("element at {0} is {1}",ind,a[ind]);
            }
            catch(IndexOutOfRangeException ob)
            {
                Console.WriteLine("EXCEPTION : " + ob.Message );
            }
        }
    }
}
