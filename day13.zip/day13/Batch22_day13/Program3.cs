﻿using System;
using MyNamespace;

namespace Batch22_day13
{
    class Program3
    {
        static void Main(string[] args)
        {
            // MyNamespace.Namespace1 ob = new MyNamespace.Namespace1();
            Namespace1 ob = new Namespace1();
            ob.areafun();
            ob.checkvalidity();
        }
    }
}
