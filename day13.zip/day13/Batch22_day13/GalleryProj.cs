﻿using System;

namespace Batch22_day13
{
    interface Pictures
    {
        void zoomin();
        void zoomout();
    }
    interface Videos
    {
        void mute();
        void audioup();
        void audiodown();
    }

    class GalleryProj:Pictures,Videos
    {
        string itemname, itemtype;
        public GalleryProj()
        {
            Console.WriteLine("Enter the item name and type");
            itemname = Console.ReadLine();
            itemtype = Console.ReadLine();
        }
        public void zoomin()
        {
            Console.WriteLine("Zooming in "+itemname);
        }
        public void zoomout()
        {
            Console.WriteLine("Zooming out" + itemname);
        }
        public void mute()
        {
            Console.WriteLine("Mute the video =  " + itemname);
        }
        public void audioup()
        {
            Console.WriteLine("Increase the volume =  " + itemname);

        }
        public void audiodown()
        {
            Console.WriteLine("Decrease  the volume =  " + itemname);
        }
        public void display()
        {
            if(itemtype == "Pictures")
            {
                zoomin();
                zoomout();
            }
            else if(itemtype == "Videos")
            {
                Console.WriteLine("enter 1 mute 2 increase vol 3 decrease vol");
                int ch = int.Parse(Console.ReadLine());
                if (ch == 1)
                    mute();
                else if (ch == 2)
                    audioup();
                else
                    audiodown();
            }
            else
                Console.WriteLine("invalid format");
        }
    }
}
